﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=Footballers;Trusted_Connection=True;Integrated Security=false;User Id=sa;Password=Docker@123";
    }
}
